##
##  [tvlp_main.R] Time-varying local projections
##                with stochastic volatility (SV)
##
##  Coded by: Jouchi Nakajima
##  Last update: 2025/03/28
##  Website:  http://sites.google.com/site/jnakajimaweb/
##
##  ** You may use and modify this code at your own risk
##

##--- initial setup ---##
rm(list=ls())
gc()
gc()
tic.time <- proc.time()
library(tidyverse)
library(ggplot2)
library(RColorBrewer)


##--- [SET] option ---##

iSV <- 1       # SV (0: off, 1: on)

dz <- 1        # width of credible intervals (stdev)

nh <- 8        # maximum horizons to draw impulse responses

ix <- 1        # index of variable to draw

vt <- c(20, 40, 60, 80, 100)  # index of time points to draw
                              # (should be >= nh)

sf <- '.jpeg'  # figure file extension


##--- load results and set variables ---##

vscol <- c("#A7293A", "#7570F3")

vh <- c(1 : nh)
vid <- (ix-1)*2 + c(1:2)

for (h in 1:nh) {
  
  mout <- as.matrix(read.csv(
    paste(ifelse(iSV == 1, 'result_sv', 'result_cv'),
          h, '.csv', sep='')))
  
  if (h == 1) {
    ns <- nrow(mout)
    amd <- array(0, dim = c(ns, 3, nh))
    
    if (iSV == 1) {
      ams <- amd
      nk <- ncol(mout)
    }
  }
  
  md <- cbind(mout[, vid[1]],
              mout[, vid[1]] - mout[, vid[2]] * dz,
              mout[, vid[1]] + mout[, vid[2]] * dz)
  
  amd[, , h] <- rbind(matrix(0, (h-1), 3), md)
  
  if (iSV == 1) {
    
    ms <- cbind(mout[, nk-1],
                mout[, nk-1] - mout[, nk] * dz,
                mout[, nk-1] + mout[, nk] * dz)
    
    ams[, , h] <- rbind(matrix(0, (h-1), 3), ms)
    
  }
  
}

vxlim <- c(0, ns)
vylim <- c(min(amd), max(amd))


##--- Impulse response (time-series plot) ---##

for (h in 1:nh) {
  
  md <- amd[h:ns, , h]
  
  df.res <- data.frame(time = c(h:ns),
                       x1 = md[, 1], x2 = md[, 2], x3 = md[, 3])
  
  df.out <- df.res %>%
    tidyr::gather(key = varname, value = value, x1, x2)
  
  pl.out <-
    ggplot(df.out, aes(x = time, y = value, color = varname,
                       linetype = varname)) +
    geom_hline(yintercept = 0, color="azure4", linewidth=.3) +
    geom_vline(xintercept = 0, color="azure4", linewidth=.3) +
    geom_line() +
    scale_color_manual(values = vscol) +
    scale_linetype_manual(values = c(x1 = "solid", x2 = "dashed", x3 = "dashed"),
                          guide="none") +
    geom_line(aes(y = x3, linetype="x3")) +
    ggtitle(paste('h =', h)) +
    theme_minimal() +
    theme(legend.position = "none",
          plot.title = element_text(size = 12, face="italic")) +
    guides(color = guide_legend(nrow = 1, byrow = TRUE)) +
    xlab("") + ylab("") +
    coord_cartesian(xlim = vxlim, ylim = vylim, clip = "off") +
    theme(text = element_text(size = 14))
  
  show(pl.out)
  
  ggsave(paste('fig-irf-h', h, sf, sep = ''),
         plot = pl.out, width = 4, height = 3.2, units = 'in')
}

##--- Impulse response (time-point plot) ---##

vt <- vt[(vt >= nh) & (vt <= ns)]
nt <- length(vt)
mxm <- mxl <- mxu <- matrix(0, nt, nh)

for (h in 1:nh) {
  mxm[, h] <- amd[vt, 1, h]
  mxl[, h] <- amd[vt, 2, h]
  mxu[, h] <- amd[vt, 3, h]
}

for (i in 1:nt) {
  
  df.res <- data.frame(time = c(1:nh),
                       x1 = mxm[i, ], x2 = mxl[i, ], x3 = mxu[i, ])
  
  df.out <- df.res %>%
    tidyr::gather(key = varname, value = value, x1, x2)
  
  pl.out <-
    ggplot(df.out, aes(x = time, y = value, color = varname,
                       linetype = varname)) +
    geom_hline(yintercept = 0,   color="azure4", linewidth=.3) +
    geom_vline(xintercept = 1, color="azure4", linewidth=.3) +
    geom_line() +
    scale_color_manual(values = vscol) +
    scale_linetype_manual(values = c(x1 = "solid", x2 = "dashed", x3 = "dashed"),
                          guide="none") +
    geom_line(aes(y = x3, linetype="x3")) +
    ggtitle(paste('t =', vt[i])) +
    theme_minimal() +
    theme(legend.position = "none",
          plot.title = element_text(size = 12, face="italic")) +
    guides(color = guide_legend(nrow = 1, byrow = TRUE)) +
    xlab("") + ylab("") +
    coord_cartesian(xlim = c(1,nh), ylim = vylim, clip = "off") +
    theme(text = element_text(size = 13))
  
  show(pl.out)
  
  ggsave(paste('fig-irf-t', vt[i], sf, sep = ''),
         plot = pl.out, width = 3.5, height = 3.2, units = 'in')
}

##--- SV ---##

if (iSV == 1) {
  
  ams <- exp(ams / 2)
  vylims <- c(0, max(ams))
  
  for (h in 1:nh) {
    
    ms <- ams[h:ns, , h]
    
    df.res <- data.frame(time = c(h:ns),
                         x1 = ms[, 1], x2 = ms[, 2], x3 = ms[, 3])
    
    df.out <- df.res %>%
      tidyr::gather(key = varname, value = value, x1, x2)
    
    pl.out <-
      ggplot(df.out, aes(x = time, y = value, color = varname,
                         linetype = varname)) +
      geom_hline(yintercept = 0,   color="azure4", linewidth=.3) +
      geom_vline(xintercept = 0, color="azure4", linewidth=.3) +
      geom_line() +
      scale_color_manual(values = vscol) +
      scale_linetype_manual(values = c(x1 = "solid", x2 = "dashed", x3 = "dashed"),
                            guide="none") +
      geom_line(aes(y = x3, linetype="x3")) +
      ggtitle(paste('h =', h)) +
      theme_minimal() +
      theme(legend.position = "none",
            plot.title = element_text(size = 12, face="italic")) +
      guides(color = guide_legend(nrow = 1, byrow = TRUE)) +
      xlab("") + ylab("") +
      coord_cartesian(xlim = vxlim, ylim = vylims, clip = "off") +
      theme(text = element_text(size = 14))
    
    show(pl.out)
    
    ggsave(paste('fig-sv', h, sf, sep = ''),
           plot = pl.out, width = 4, height = 3.2, units = 'in')
    
  }
}