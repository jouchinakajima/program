##
##  [tvlp_svsamp.R] generates sample from conditional
##                  posterior distribution of SV
##
##  Coded by: Jouchi Nakajima
##  Last update: 2025/03/28
##  Website:  http://sites.google.com/site/jnakajimaweb/
##
##  ** You may use and modify this code at your own risk
##

svsamp <- function(vy, vh, dsig2, dh00, dsig02, nK) {

  ns <- length(vy)
  nite <- 3

  vhs <- vh

  vk <- c(1, 2)
  while (sum(diff(vk) < 2) > 0) {
    vk <- c(1, floor(ns * (seq_len(nK) + runif(nK)) / (nK + 2)), ns + 1)
  }

  for (i in 1:(nK+1)) {
    ir <- vk[i]
    id <- vk[i+1] - vk[i]
    ird <- vk[i+1] - 1

    vyi <- vy[ir:ird]
    vho <- vh[ir:ird]
    vhn <- numeric(id)

    if (i <= nK) {
      dhrd1 <- vh[ird+1]
    }

    for (j in 1:(nite+1)) {
      if (j == 1) {
        vhh <- vho
      } else {
        vhh <- vhn
      }

      vgder2 <- -0.5 * vyi^2 / exp(vhh)
      vgder1 <- -0.5 - vgder2
      vsiga2 <- -1 / vgder2
      vha <- vhh + vsiga2 * vgder1

      if (i <= nK) {
        vsiga2[id] <- 1 / (-vgder2[id] + 1 / dsig2)
        vha[id] <- vsiga2[id] * (vgder1[id] -
                                 vgder2[id] * vhh[id] + dhrd1 / dsig2)
      }

      if (i == 1) {
        dh0 <- dh00
        dH20 <- dsig02
      } else {
        dh0 <- vhs[ir-1]
        dH20 <- dsig2
      }

      da <- dh0
      dP <- dH20
      dH2 <- dsig2
      ve <- numeric(id)
      vDinv <- numeric(id)
      vK <- numeric(id)
      vL <- numeric(id)
      vu <- numeric(id)

      for (t in 1:id) {
        ve[t] <- vha[t] - da
        vDinv[t] <- 1 / (dP + vsiga2[t])
        vK[t] <- dP * vDinv[t]
        vL[t] <- 1 - vK[t]

        da <- da + vK[t] * ve[t]
        dP <- dP * vL[t] + dH2
      }

      if (j <= nite) {

        dr <- 0
        dU <- 0

        for (t in id:1) {
          dC <- dH2 * (1 - dU * dH2)
          deps <- 0
          vu[t] <- dH2 * dr + deps
          dV <- dH2 * dU * vL[t]

          dCinv <- 1 / dC
          dr <- vDinv[t] * ve[t] + vL[t] * dr - dV * dCinv * deps
          dU <- vDinv[t] + vL[t]^2 * dU + dV^2 * dCinv
        }

        du0 <- dH20 * dr
        vhn[1] <- dh0 + du0
        for (t in 1:(id-1)) {
          vhn[t + 1] <- vhn[t] + vu[t]
        }

      } else {

        fl <- 0
        icyc <- 0
        while (fl == 0 && icyc < 100) {

          dr <- 0
          dU <- 0
          for (t in id:1) {
            dC <- dH2 * (1 - dU * dH2)
            deps <- sqrt(dC) * rnorm(1)
            vu[t] <- dH2 * dr + deps
            dV <- dH2 * dU * vL[t]

            dCinv <- 1 / dC
            dr <- vDinv[t] * ve[t] + vL[t] * dr -
                  dV * dCinv * deps
            dU <- vDinv[t] + vL[t]^2 * dU + dV^2 * dCinv
          }

          dC <- dH20 * (1 - dU * dH20)
          du0 <- dH20 * dr + sqrt(dC) * rnorm(1)
          vhn[1] <- dh0 + du0
          for (t in 1:(id-1)) {
            vhn[t+1] <- vhn[t] + vu[t]
          }

          dpron <- sum(-0.5 * (vhh + vyi^2 / exp(vhh)) +
                       vgder1 * (vhn - vhh) +
                       0.5 * vgder2 * (vhn - vhh)^2)

          dposn <- sum(-0.5 * (vhn + vyi^2 / exp(vhn)))

          dfrac <- exp(dposn - dpron)

          if (is.na(dfrac)) dfrac <- 0

          if (runif(1) < dfrac) fl <- 1

          icyc <- icyc + 1
        }
      }
    }

    if (icyc < 100) {

      dproo <- sum(-0.5 * (vhh + vyi^2 / exp(vhh)) +
                    vgder1 * (vho - vhh) +
                    0.5 * vgder2 * (vho - vhh)^2)

      dposo <- sum(-0.5 * (vho + vyi^2 / exp(vho)))

      dfrac <- exp(dposn + min(c(dposo, dproo)) -
                   dposo - min(c(dposn, dpron)))

      if (runif(1) < dfrac) vhs[ir:ird] <- vhn
    }
  }

  return(vhs)
}
