R codes for
Time-varying local projection with stochastic volatility (SV)

Coded by: Jouchi Nakajima
Last update: 2025/03/28
Website:  http://sites.google.com/site/jnakajimaweb/

** Please cite the following working paper in products involving the application of this R codes
> Nakajima, J. (2025). "Time-varying local projections with stochastic volatility" Discussion Paper Series A.761, Institute of Economic Research, Hitotsubashi University.
** You may use and modify this code at your own risk

(1) tvlp_main.R
Main file. Look at the [SET] sections, specify your setting, and run.
Output files:
> result_tvX.csv - Posterior means and standard deviations of time-varying coefficients and stochastic volatility at the X-th horizon, which are used for Code (2).

(2) tvlp_draw.R
Drawing figures after running Code (1). Look at the [SET] section, specify your setting, and run.
Output files (zzz = specified figure-file extension):
> fig-irf-hX.zzz - Time-series plot of time-varying impulse response functions at the X-th horizon.
> fig-irf-tYY.zzz - Time-point plot of time-varying impulse response functions at the time t = YY.
> fig-sv-hX.zzz - Time-series plot of SV, exp(gamma_t/2).

(3) tvlp_data.csv
Sample data.

