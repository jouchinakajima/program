##
##  [tvpvar_main.R] Time-Varying Parameter (TVP) VAR model
##                  with stochastic volatility (SV)
##                  This code implements MCMC estimation of TVP-VAR
##
##  Coded by: Jouchi Nakajima
##  Last update: 2025/08/01
##  Website:  http://sites.google.com/site/jnakajimaweb/
##
##  ** You may use and modify this code at your own risk
##


##--- initial setup ---##
rm(list=ls())
gc()
gc()
library(stats)
source("tvpvar_subfunc.R")
tic.time <- proc.time()
set.seed(1)


##--- [SET] options ---##

fli <- 0         # time-varying intercept (0: off, 1: on)

flSb <- 0        # Sigma_b (0: diagonal, 1: non-diagonal)

flfi <- 1        # fast computing of impulse (0: off, 1:on)

nsim  <- 20000   # the number of iterations


##--- [SET] data file and variables ---##

mdata <- as.matrix(read.csv('tvpvar_ex.csv'))  # load data

my <- mdata[, 1:3]    # variables (y)

nl <- 2        # the number of lags

nimp <- 12     # length of impulse response

asvar <- colnames(my)  # variable names


##--- set variables ---##

ns <- nrow(my)
nk <- ncol(my)

nb <- nk * (nk*nl + fli) # size of beta
na <- nk * (nk-1) / 2    # size of alpha

if (fli == 1) {
  vym <- rep(0, nk)
} else {
  vym <- colMeans(my)
}
my <- my - t(matrix(vym, nk, ns))

myh <- mya <- matrix(0, ns, nk)
amX <- array(0, dim = c(nk, nb, ns))
amXh <- array(0, dim = c(nk, na, ns))
amG2 <- array(0, dim = c(nk, nk, ns))
mai <- matrix(0, ns, na)
for (i in (nl+1):ns) {
  amX[, , i] <- fXt(my[(i-1):(i-nl), ], fli)
}

mb <- matrix(0, ns, nb)
ma <- matrix(0, ns, na)
mh <- matrix(0, ns, nk)

mSigb <- diag(nb) * 0.01
mSiga <- diag(na) * 0.01
mSigh <- diag(nk) * 0.01

vidb <- c(1 : nb)
if (fli == 1) {
  vidb <- vidb[(vidb %% (nk*nl+1)) != 1]
  vidi <- (0 : (nk-1)) * (nk*nl+1) + 1
}
mInd <- matrix(1:(nk^2), nk, nk)
vida <- rep(0, na)
j1 <- 1
for (i in 2:nk) {
  j2 <- j1 + (i-2)
  vida[j1:j2] <- mInd[i, 1:(i-1)]
  j1 <- j2 + 1
}

nimp <- nimp + 1

##--- set priors ---##

if (flSb == 1) {
  dvb0 <- 25       # Sigma ~ IW(vb0, I*Vb0)
  dVb0 <- 1e-4
} else {
  dvb0 <- 40       # sigb_i^2 ~ IG(vb0/2 Vb0/2)
  dVb0 <- 2 * 1e-4
}
dva0 <- 8          # siga_i^2 ~ IG(va0/2 Va0/2)
dVa0 <- 2*1e-4
dvh0 <- 8          # sigh_i^2 ~ IG(vh0/2 Vah0/2)
dVh0 <- 2*1e-4

vb0  <- rep(0, nb)  # b_1 ~ N(b0, Sb0)
mSb0 <- diag(nb) * 10
va0  <- rep(0, na)  # a_1 ~ N(a0, Sa0)
mSa0 <- diag(na) * 10
vh0  <- rep(0, nk)  # b_1 ~ N(h0, Sh0)
mSh0 <- diag(nk) * 50

mS0 <- diag(nb) * dVb0
dnub <- dvb0 + ns - nl - 1
dnua <- dva0 + ns - nl - 1
dnuh <- dvh0 + ns - nl - 1


##-- set sampling option --##

nburn <- 0.1 * nsim             # burn-in period
npmt  <- 5                      # the number of parameters
vsamp <- rep(0, npmt)           # sample box
msamp <- matrix(0, nsim, npmt)  # store box
msamph <- msamphs <- matrix(0, ns, nk)
msampa  <- msampas <-
msampai <- msampais <- matrix(0, ns, na)
if (fli == 1) {
  msampi <- msampis <- matrix(0, ns, nk)
}
if (flfi == 1) {
  msampb <- matrix(0, ns, length(vidb))
} else {
  mimpm <- matrix(0, ns*nimp, nk^2)
}
nK <- floor(ns/30)-1            # blocks for sampling h


##-- MCMC sampling --##

cat('\nIteration:\n')

##----------------- S A M P L I N G   S T A R T ----------------##

for(k in (-nburn+1):nsim){

  ##--- sampling beta ---##

  for (i in (nl+1):ns) {

    mAinv <- solve(fAt(ma[i, ]))
    amG2[, , i] <- mAinv %*% diag(exp(mh[i, ])) %*% t(mAinv)
    mai[i, ] <- mAinv[vida]

  }

  mb[(nl+1):ns, ] <- ssmooth(my[(nl+1):ns, ], amX[, , (nl+1):ns],
                             amG2[, , (nl+1):ns], mSigb, vb0, mSb0)


  ##--- sampling a ---##

  for (i in (nl+1):ns) {
    myh[i, ] <- my[i, ] - mb[i, ] %*% t(amX[, , i])
    amXh[, , i] <- fXh(myh[i, ])
    amG2[, , i] <- diag(exp(mh[i, ]))
  }

  ma[(nl+1):ns, ] <- ssmooth(myh[(nl+1):ns, ], amXh[, , (nl+1):ns],
                             amG2[, , (nl+1):ns], mSiga, va0, mSa0)


  ##--- sampling h ---##

  for (i in (nl+1):ns) {
    mya[i, ] <- myh[i, ] %*% t(fAt(ma[i, ]))
  }

  for (i in 1:nk) {
    mh[(nl+1):ns, i] <- svsamp(mya[(nl+1):ns, i], mh[(nl+1):ns, i],
                               mSigh[i, i], vh0[i], mSh0[i, i], nK)
  }


  ##--- sampling Sigma ---##

  mdif <- diff(mb[(nl+1):ns, ])
  if (flSb == 1) {
    mSb <- mS0 + t(mdif) %*% mdif
    mSb <- (mSb + t(mSb)) / 2
    if (det(mSb) <= 0) {
      mSb <- diag(diag(mSb))
    }
    mSigbi <- rWishart(1, dnub,  solve(mSb))
    mSigb <- solve(matrix(mSigbi, nb, nb))
  } else {
    vSb <- dVb0 + colSums(mdif^2)
    for (i in 1:nb) {
      mSigb[i, i] <- 1 / rgamma(1, dnub/2, vSb[i]/2)
    }
  }

  vSa <- dVa0 + colSums(diff(ma[(nl+1):ns, ])^2)
  for (i in 1:na) {
    mSiga[i, i] <- 1 / rgamma(1, dnua/2, vSa[i]/2)
  }

  vSh <- dVh0 + colSums(diff(mh[(nl+1):ns, ])^2)
  for (i in 1:nk) {
    mSigh[i, i] <- 1 / rgamma(1, dnuh/2, vSh[i]/2)
  }


  if (k >= 1) {

    ##--- storing sample ---##

    msamp[k, ] <- c(mSigb[1, 1], mSigb[2, 2], mSiga[1, 1],
                    mSigh[1, 1], mSigh[2, 2])

    msamph   <- msamph  + mh
    msamphs  <- msamphs + mh^2
    msampa   <- msampa  + ma
    msampas  <- msampas + ma^2
    msampai  <- msampai  + mai
    msampais <- msampais + mai^2

    if (fli == 1) {
      msampi  <- msampi  + mb[, vidi]
      msampis <- msampis + mb[, vidi]^2
    }   
    if (flfi == 1) {
      msampb <- msampb + mb[, vidb]
    } else {

      ##--- impulse response ---##

      mimpi <- impulse(nl, nimp, mb[, vidb], ma, mh)
      mimpm <- mimpm + mimpi

    }
  }

  if((k %% 100) == 0) cat(k, '\n')

}
##------------------- S A M P L I N G   E N D ------------------##

##--- output results ---##

## Parameters
msamp <- sqrt(msamp)
mout <- matrix(0, npmt, 4)
for (i in 1:npmt) {
  mout[i, ] <- c(mean(msamp[, i]), sd(msamp[, i]),
                 quantile(msamp[, i], .025, type=1),
                 quantile(msamp[, i], .975, type=1))
}
vspar <- c('sb1   ', 'sb2   ', 'sa1   ', 'sh1   ', 'sh2   ')

cat('\n')
cat('--------------------------------------------\n')
cat('Parameter  Mean     Stdev    95%L     95%U\n')
cat('--------------------------------------------\n')
for (i in 1:npmt) {
  cat(paste(vspar[i], ' ',
            sprintf('%7.4f', mout[i, 1]), '',
            sprintf('%7.4f', mout[i, 2]), '',
            sprintf('%7.4f', mout[i, 3]), '',
            sprintf('%7.4f', mout[i, 4]), '\n'))
}
cat('--------------------------------------------\n')
cat(paste('TVP-VAR model (Lag = ', nl, ')    ', sep=''))
cat(paste('Iteration: ', nsim, '\n', sep=''))
if (flSb == 0){
  cat('Sigma(b): Diagonal\n')
}

## SV
msamph <- msamph[(nl+1):ns, ] / nsim
msamphs <- sqrt(msamphs[(nl+1):ns, ] / nsim - msamph^2)

mout <- rbind(matrix(NA, nl, na*2), cbind(msamph, msamphs))

svar <- rep('', nk*2)
for (i in 1:nk) {
  svar[i]    <- paste('SV(', asvar[i], ')-Mean', sep='')
  svar[i+nk] <- paste('SV(', asvar[i], ')-SD', sep='')
}

colnames(mout) <- svar
write.csv(mout, paste('tvpvar_vol.csv'), row.names = F)

## a_t
msampa  <- msampa[(nl+1):ns, ] / nsim
msampas <- sqrt(msampas[(nl+1):ns, ] / nsim - msampa^2)

mout <- rbind(matrix(NA, nl, na*2), cbind(msampa, msampas))
svar <- rep('', na*2)
for (i in 1:nk) {
  svar[i]    <- paste('a', i, '-Mean', sep='')
  svar[i+nk] <- paste('a', i, '-SD', sep='')
}
colnames(mout) <- svar
write.csv(mout, paste('tvpvar_a.csv'), row.names = F)

## a_t inverse
msampai  <- msampai[(nl+1):ns, ] / nsim
msampais <- sqrt(msampais[(nl+1):ns, ] / nsim - msampai^2)

mout <- rbind(matrix(NA, nl, na*2), cbind(msampai, msampais))
svar <- rep('', na*2)
for (i in 1:nk) {
  svar[i]    <- paste('ai', i, '-Mean', sep='')
  svar[i+nk] <- paste('ai', i, '-SD', sep='')
}
colnames(mout) <- svar
write.csv(mout, paste('tvpvar_ai.csv'), row.names = F)

## intercept
if (fli == 1) {
  msampi  <- msampi[(nl+1):ns, ] / nsim
  msampis <- sqrt(msampis[(nl+1):ns, ] / nsim - msampi^2)

  mout <- rbind(matrix(NA, nl, na*2), cbind(msampi, msampis))
  svar <- rep('', na*2)
  for (i in 1:nk) {
    svar[i]    <- paste('c(', asvar[i], ')-Mean', sep='')
    svar[i+nk] <- paste('c(', asvar[i], ')-SD', sep='')
  }
  colnames(mout) <- svar
  write.csv(mout, paste('tvpvar_int.csv'), row.names = F)
}

##--- save impulse response ---##

msampa <- rbind(matrix(0, nl, na), msampa)
msamph <- rbind(matrix(0, nl, nk), msamph)
if (flfi == 1) {
  mimpm <- impulse(nl, nimp, msampb/nsim, msampa, msamph)
} else {
  mimpm <- mimpm / nsim
}

mimpm[1:(nimp*nl), ] <- NA

mout <- cbind(kronecker((1:ns), rep(1,nimp)), rep(0:(nimp-1), ns), mimpm)
svar <- rep('', nk^2)
for (i in 1:nk) {
  for (j in 1:nk) {
    svar[(i-1)*nk+j] <- paste(asvar[j], '_response to ',
                              asvar[i], '_shock', sep='')
  }
}
svar <- c('t', 'horizon', svar)
colnames(mout) <- svar

write.csv(mout, paste('tvpvar_imp.csv'), row.names = F)



##--- run time ---##

total.time <- proc.time() - tic.time
message('\nTime(s): ', round(total.time[3], 1))

