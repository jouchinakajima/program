##
##  [tvpvar_draw.R] Time-Varying Parameter (TVP) VAR model
##                  with stochastic volatility (SV)
##                  This code draws figures of impulse response
##
##  Coded by: Jouchi Nakajima
##  Last update: 2025/08/01
##  Website:  http://sites.google.com/site/jnakajimaweb/
##
##  ** You may use and modify this code at your own risk
##


##--- initial setup ---##
rm(list=ls())
gc()
gc()
library(tidyverse)
library(ggplot2)
library(gridExtra)


##--- [SET] figure style and selected times ---##

fldraw <- 0   # 0: impulse responses at selected time points
              # 1: time series of impulse responses at selected horizons

if (fldraw == 0) {

  vt <- c(30, 60, 90) # [input 3 time points] t = 30, 60, 90

} else {

  vt <- c(4, 8, 12)   # [input 3 time horizons] 4-, 8-, 12-period ahead

}

sf <- '.jpeg'  # figure file extension



##--- set variables ---##

mimpr <- as.matrix(read.csv('tvpvar_imp.csv'))  # output from tvpvar_main.R

mimpm <- mimpr[, 3:ncol(mimpr)]
nimp <- max(mimpr[, 2]) + 1

ns <- nrow(mimpm) / nimp
nk <- sqrt(ncol(mimpm))
nl <- sum(is.na(mimpm[, 1])) / nimp

svar <- colnames(mimpm)

vscol <- c("#A7293A", "#7570F3", "#08A415")

if (fldraw == 0) {
  sxla <- 't ='
  sxlb <- 'Horizon (h)'
  vbx <- seq(0, (nimp-1), 4)
} else {
  sxla <- 'h ='
  sxlb <- 'Time (t)'
}


##--- draw impulse response ---##

pl.out.list <- list()

for (i in 1:nk) {
  for (j in 1:nk) {

    id <- (i-1) * nk + j
    mimp <- t(matrix(mimpm[, id], nimp, ns))

    if (fldraw == 0) {
      mout <- mimp[vt, ]
      df.res <- data.frame(time = c(0:(nimp-1)),
                           x1 = mout[1, ], x2 = mout[2, ], x3 = mout[3, ])
    } else {
      mout <- mimp[(nl+1):ns, vt+1]
      df.res <- data.frame(time = c((nl+1):ns),
                           x1 = mout[, 1], x2 = mout[, 2], x3 = mout[, 3])
    }

    df.out <- df.res %>%
      tidyr::gather(key = varname, value = value, x1, x2, x3)

    pl.out <-
      ggplot(df.out, aes(x = time, y = value, color = varname)) +
      geom_hline(yintercept = 0, color="azure4", linewidth=.3) +
      geom_vline(xintercept = 0, color="azure4", linewidth=.3) +
      geom_line() +
      ggtitle(svar[(i-1)*nk+j]) +
      theme_minimal() +
      theme(plot.title = element_text(size = 10)) +
      xlab(sxlb) + ylab("") +
      theme(text = element_text(size = 10))

    if (id == 1) {
      pl.out <- pl.out +
        scale_color_manual(values = vscol,
                           labels = c(x1 = paste(sxla, vt[1]),
                                      x2 = paste(sxla, vt[2]),
                                      x3 = paste(sxla, vt[3]))) +
        theme(legend.title = element_blank(),
              legend.text = element_text(size = 10),
              legend.position = c(0.95, 0.5),
              legend.justification = c(1, 1))
    } else {
      pl.out <- pl.out +
        scale_color_manual(values = vscol) +
        theme(legend.position = "none")
    }
    if (fldraw == 0) {
      pl.out <- pl.out +
        scale_x_continuous(breaks = vbx)
    }

    pl.out.list[[id]] <- pl.out

  }
}

pl.all <- c(pl.out.list, list(ncol=nk, nrow=nk))
pl.fin <- do.call(grid.arrange, pl.all)

ggsave(paste('tvpvar_imp', sf, sep = ''),
       plot = pl.fin, width = 10, height = 10, units = 'in')


