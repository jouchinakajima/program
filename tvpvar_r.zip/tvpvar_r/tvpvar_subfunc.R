##
##  [tvpvar_subfunc.R] Time-Varying Parameter (TVP) VAR model
##                     with stochastic volatility (SV)
##                     This file contains sub-functions
##
##  Coded by: Jouchi Nakajima
##  Last update: 2025/08/01
##  Website:  http://sites.google.com/site/jnakajimaweb/
##
##  ** You may use and modify this code at your own risk
##

##
##  "ssmooth" implements simulation smoother
##
ssmooth <- function(my, amZ, amG2, mH2, va0, mH02) {

  ##--- set variables ---##

  ns <- nrow(my)
  nk <- ncol(my)
  np <- nrow(mH2)

  va <- va0
  mP <- mH02
  vr <- rep(0, np)
  mU <- diag(np) * 0
  me <- matrix(0, nk, ns)
  amDinv <- array(0, dim = c(nk, nk, ns))
  amL <- array(0, dim = c(np, np, ns))
  meta <- matrix(0, np, ns)


  ##--- Kalman filter ---##

  for (i in 1:ns) {
    me[, i] <- my[i, ] - amZ[, , i] %*% va
    mD <- amZ[, , i] %*% mP %*% t(amZ[, , i]) + amG2[, , i]

    if (det(mD) > 0) {
      mDinv <- solve(mD)
    } else {
      mDinv <- diag(nk) * 10
    }

    amDinv[, , i] <- mDinv
    mK <- mP %*% t(amZ[, , i]) %*% mDinv
    amL[, , i] <- diag(np) - mK %*% amZ[, , i]

    va <- va + mK %*% me[, i]
    mP <- mP %*% t(amL[, , i]) + mH2
  }

  for (i in ns:1) {
    mC <- mH2 - mH2 %*% mU %*% mH2
    mC <- (mC + t(mC)) / 2
    if (det(mC) > 0) {
      mCc <- t(chol(mC))
      mCinv <- solve(mC)
    } else {
      mCc <- eye(np) * .01
      mCinv <- eye(np) * 10^4
    }

    veps <- mCc %*% rnorm(np)
    meta[, i] <- mH2 %*% vr + veps
    mV <- mH2 %*% mU %*% amL[, , i]

    vr <- t(amZ[, , i]) %*% amDinv[, , i] %*% me[, i] +
          t(amL[, , i]) %*% vr - t(mV) %*% mCinv %*% veps
    mU <- t(amZ[, , i]) %*% amDinv[, , i] %*% amZ[, , i] +
          t(amL[, , i]) %*% mU %*% amL[, , i] +
          t(mV) %*% mCinv %*% mV
  }

  mC <- mH02 - mH02 %*% mU %*% mH02
  mC <- (mC + t(mC)) / 2
  if(det(mC) > 0) {
    mCc <- t(chol(mC))
  } else {
    mCc <- diag(np) * .07
  }
  veta0 <- mH02 %*% vr + mCc %*% rnorm(np)

  malpha <- matrix(0, ns, np)

  malpha[1, ] <- va0 + veta0
  for (i in 1:(ns-1)) {
    malpha[i+1, ] <- malpha[i, ] + meta[, i]
  }

  return(malpha)
}

##
##  "svsamp" implements sampling algorithm for SV
##
svsamp <- function(vy, vh, dsig2, dh00, dsig02, nK) {

  ns <- length(vy)
  nite <- 3

  vhs <- vh

  vk <- c(1, 2)
  while (sum(diff(vk) < 2) > 0) {
    vk <- c(1, floor(ns * (seq_len(nK) + runif(nK)) / (nK + 2)), ns + 1)
  }

  for (i in 1:(nK+1)) {
    ir <- vk[i]
    id <- vk[i+1] - vk[i]
    ird <- vk[i+1] - 1

    vyi <- vy[ir:ird]
    vho <- vh[ir:ird]
    vhn <- numeric(id)

    if (i <= nK) {
      dhrd1 <- vh[ird+1]
    }

    for (j in 1:(nite+1)) {
      if (j == 1) {
        vhh <- vho
      } else {
        vhh <- vhn
      }

      vgder2 <- -0.5 * vyi^2 / exp(vhh)
      vgder1 <- -0.5 - vgder2
      vsiga2 <- -1 / vgder2
      vha <- vhh + vsiga2 * vgder1

      if (i <= nK) {
        vsiga2[id] <- 1 / (-vgder2[id] + 1 / dsig2)
        vha[id] <- vsiga2[id] * (vgder1[id] -
                                 vgder2[id] * vhh[id] + dhrd1 / dsig2)
      }

      if (i == 1) {
        dh0 <- dh00
        dH20 <- dsig02
      } else {
        dh0 <- vhs[ir-1]
        dH20 <- dsig2
      }

      da <- dh0
      dP <- dH20
      dH2 <- dsig2
      ve <- numeric(id)
      vDinv <- numeric(id)
      vK <- numeric(id)
      vL <- numeric(id)
      vu <- numeric(id)

      for (t in 1:id) {
        ve[t] <- vha[t] - da
        vDinv[t] <- 1 / (dP + vsiga2[t])
        vK[t] <- dP * vDinv[t]
        vL[t] <- 1 - vK[t]

        da <- da + vK[t] * ve[t]
        dP <- dP * vL[t] + dH2
      }

      if (j <= nite) {

        dr <- 0
        dU <- 0

        for (t in id:1) {
          dC <- dH2 * (1 - dU * dH2)
          deps <- 0
          vu[t] <- dH2 * dr + deps
          dV <- dH2 * dU * vL[t]

          dCinv <- 1 / dC
          dr <- vDinv[t] * ve[t] + vL[t] * dr - dV * dCinv * deps
          dU <- vDinv[t] + vL[t]^2 * dU + dV^2 * dCinv
        }

        du0 <- dH20 * dr
        vhn[1] <- dh0 + du0
        for (t in 1:(id-1)) {
          vhn[t + 1] <- vhn[t] + vu[t]
        }

      } else {

        fl <- 0
        icyc <- 0
        while (fl == 0 && icyc < 100) {

          dr <- 0
          dU <- 0
          for (t in id:1) {
            dC <- dH2 * (1 - dU * dH2)
            deps <- sqrt(dC) * rnorm(1)
            vu[t] <- dH2 * dr + deps
            dV <- dH2 * dU * vL[t]

            dCinv <- 1 / dC
            dr <- vDinv[t] * ve[t] + vL[t] * dr -
                  dV * dCinv * deps
            dU <- vDinv[t] + vL[t]^2 * dU + dV^2 * dCinv
          }

          dC <- dH20 * (1 - dU * dH20)
          du0 <- dH20 * dr + sqrt(dC) * rnorm(1)
          vhn[1] <- dh0 + du0
          for (t in 1:(id-1)) {
            vhn[t+1] <- vhn[t] + vu[t]
          }

          dpron <- sum(-0.5 * (vhh + vyi^2 / exp(vhh)) +
                       vgder1 * (vhn - vhh) +
                       0.5 * vgder2 * (vhn - vhh)^2)

          dposn <- sum(-0.5 * (vhn + vyi^2 / exp(vhn)))

          dfrac <- exp(dposn - dpron)

          if (is.na(dfrac)) dfrac <- 0

          if (runif(1) < dfrac) fl <- 1

          icyc <- icyc + 1
        }
      }
    }

    if (icyc < 100) {

      dproo <- sum(-0.5 * (vhh + vyi^2 / exp(vhh)) +
                    vgder1 * (vho - vhh) +
                    0.5 * vgder2 * (vho - vhh)^2)

      dposo <- sum(-0.5 * (vho + vyi^2 / exp(vho)))

      dfrac <- exp(dposn + min(c(dposo, dproo)) -
                   dposo - min(c(dposn, dpron)))

      if (runif(1) < dfrac) vhs[ir:ird] <- vhn
    }
  }

  return(vhs)
}

##
##  "impulse" computes impulse response function
##
impulse <- function(nl, nlen, mb, ma, mh) {

  ns <- nrow(mh)
  nk <- ncol(mh)

  mimp <- matrix(0, ns*nlen, nk^2)
  amOmsq <- array(0, dim = c(nk, nk, ns))
  my <- matrix(0, nl+nlen, nk)
  mbs <- rbind(mb, t(matrix(mb[ns, ], ncol(mb), nlen)))

  vh <- colMeans(mh[(nl+1):ns, ])  # average shock size

  for (i in 1:nk) {
    for (t in (nl+1):ns) {
      if (i == 1) {
        amOmsq[, , t] <- solve(fAt(ma[t, ])) %*% diag(exp(vh/2))
      }

      my[nl+1, ] <- amOmsq[, i, t]

      for (j in (nl+2):(nl+nlen)) {
        my[j, ] <- mbs[t+j-nl-1, ] %*% t(fXt(my[(j-1):(j-nl), ], 0))
      }

      mimp[((t-1)*nlen+1):(t*nlen), ((i-1)*nk+1):(i*nk)] <- my[(nl+1):(nl+nlen), ]
    }

  }

  return (mimp)
}

##
##  "fAt" outputs the matrix A_t
##
fAt <- function(va) {
  mAt <- diag(nk)
  for (i in 2:nk) {
    mAt[i, 1:(i-1)] <- va[((i-1)*(i-2)/2+1) : (i*(i-1)/2)]
  }

  return (mAt)
}

##
##  "fXt" outputs the matrix X_t
##
fXt <- function(myi, fli) {

  myit <- t(myi)
  if (fli == 1) {
    vyi <- cbind(1, matrix(myit, 1, nk*nl))
  } else {
    vyi <- matrix(myit, 1, nk*nl)
  }
  mXt <- kronecker(diag(nk), vyi)

  return (mXt)
}

##
##  "fXh" outputs the matrix X_hat
##
fXh <- function(vyh) {
  mXh <- matrix(0, nk, na)
  for (i in 2:nk) {
    mXh[i, ((i-1)*(i-2)/2+1) : (i*(i-1)/2)] <- (-vyh[1:(i-1)])
  }

  return (mXh)
}
