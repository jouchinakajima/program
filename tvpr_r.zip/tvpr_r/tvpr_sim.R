##
##  [tvpr_sim.R] Time-Varying Parameter Regression (TVP-R)
##               model with stochastic volatility (SV)
##               This code simulates observation from TVP-R
##
##  Coded by: Jouchi Nakajima
##  Last update: 2025/08/01
##  Website:  http://sites.google.com/site/jnakajimaweb/
##
##  ** You may use and modify this code at your own risk
##


##--- initial setup ---##
rm(list=ls())
gc()
gc()
tic.time <- proc.time()
set.seed(1)


##--- [SET] options ---##

flSV <- 1     # SV (0: off, 1: on)

ns <- 500    # sample size


##--- [SET] true parameters ---##

vb   <- c(4, -1)       # beta
va0  <- c(-2, 3)       # alpha (initial)
mSig <- diag(2) * .01  # Sigma
dphi <- 0.95           # phi
dsiget <- 0.1          # sigma_eta
dgam <- 0.5            # gamma
dsig <- 1.0            # sigma

# vb <- NULL   # no time-invariant coefficients
# va0 <- NULL  # no time-varying coefficients

##--- simulate observations ---##

nk <- length(vb)
if (nk > 0) {
  mx <- matrix(runif(ns*nk), ns, nk) - 0.5
  vxb <- mx %*% vb
} else {
  mx <- NULL
  vxb <- 0
}

np <- length(va0)
if (np > 0) {
  mz <- matrix(runif(ns*np), ns, np) - 0.5
  ma <- rbind(va0, matrix(0, ns-1, np))
  mSigch <- t(chol(mSig))
  for (i in 1:(ns-1)) {
    ma[i+1, ] <- ma[i, ] +
                 matrix(rnorm(np), 1) %*% mSigch
  }
  vza <- rowSums(mz * ma)
} else {
  mz <- NULL
  ma <- NULL
  vza <- 0
}

if (flSV == 1) {
  dh0 <- rnorm(1) * dsiget / sqrt(1 - dphi^2)
  vh <- c(dh0, rep(0, ns-1))
  for (i in 1:(ns-1)) {
    vh[i+1] <- dphi * vh[i] + rnorm(1) * dsiget
  }
  vsigt <- sqrt(dgam) * exp(vh / 2)
} else {
  vh <- NULL
  vsigt <- rnorm(ns, 1) * dsig
}

vy <- vxb + vza + rnorm(ns) * vsigt


##--- save data ---##

mdata <- cbind(vy, mx, mz, ma, vh)

svar <- "y"
if (nk > 0) {
  for (i in 1:nk) {
    svar <- c(svar, paste("x", i, sep=""))
  }
}
if (np > 0) {
  for (i in 1:np) {
    svar <- c(svar, paste("z", i, sep=""))
  }
  for (i in 1:np) {
    svar <- c(svar, paste("a", i, sep=""))
  }
}
if (flSV == 1) {
  svar <- c(svar, "h")
}

colnames(mdata) <- svar

write.csv(mdata, "tvpr_sim.csv", row.names = F)


##--- run time ---##

total.time <- proc.time() - tic.time
message('\nTime(s): ', round(total.time[3], 1))