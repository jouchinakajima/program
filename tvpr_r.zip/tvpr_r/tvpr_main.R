##
##  [tvpr_main.R] Time-Varying Parameter Regression (TVP-R)
##                model with stochastic volatility (SV)
##                This code implements MCMC estimation of TVP-R
##
##  Coded by: Jouchi Nakajima
##  Last update: 2025/08/01
##  Website:  http://sites.google.com/site/jnakajimaweb/
##
##  ** You may use and modify this code at your own risk
##


##--- initial setup ---##
rm(list=ls())
gc()
gc()
library(stats)
source("tvpr_svsamp.R")
tic.time <- proc.time()
set.seed(1)


##--- [SET] options ---##

flSV <- 1       # SV (0: off, 1: on)

nsim  <- 20000  # the number of iterations


##--- [SET] data file and variables ---##

mdata <- as.matrix(read.csv('tvpr_simdata.csv'))  # load data

vy <- mdata[, 1]      # dependent variable (y)
mx <- mdata[, 2:3]    # independent variables for non-TVP (x)
mz <- mdata[, 4:5]    # independent variables for TVP (z)


##--- set initial values ---##

ns <- length(vy)
nk <- ncol(mx)
np <- ncol(mz)

vb   <- rep(0, nk)     # beta
ma <- matrix(0, ns, np)  # alpha
mSig <- diag(2) * .1  # Sigma
vh <- rep(0, ns)       # h
dphi <- 0.95           # phi
dsiget <- 0.1          # sigma_eta
dgam <- 0.1            # gamma
dsig <- 0.1            # sigma


##--- set priors ---##

vb0 <- rep(0, nk)      # mu ~ N(b0, B0)
mB0 <- diag(nk) * 10
dnu0 <- 4              # Sigma ~ InvWishart(nu0, Om0)
mOm0 <- diag(np) * 40
va0 <- rep(0, np)      # a1 ~ N(va0, Sig0)
mSig0 <- diag(np) * 10
da0 <- 20              # (phi+1)/2 ~ Beta(a0, b0)
db0 <- 1.5
dv0 <- 4               # sigma_eta^2 ~ InvGamma(v0/2, V0/2)
dV0 <- 0.04
dg0 <- 4               # gamma ~ InvGamma(g0/2, W0/2)
dW0 <- 0.04
ds0 <- 4               # sigma ~ InvGamma(s0/2, S0/2)
dS0 <- 0.04


##--- set variables ---##

miB0 <- solve(mB0)
vBb0 <- miB0 %*% vb0
miOm0 <- solve(mOm0)
dnuh <- dnu0 + ns - 1
dvh <- dv0 + ns
dgh <- dg0 + ns
dsh <- ds0 + ns

vsigt2 <- dgam * exp(vh)
vxb <- vza <- rep(0, ns)

vr <- rep(0, np)
mU <- diag(np) * 0
mT <- diag(np)
ve <- vDi <- rep(0, ns)
amL <- array(0, dim = c(np, np, ns))
meta <- malpha <- matrix(0, ns, np)


##-- set sampling option --##

nburn <- 0.1 * nsim             # burn-in period
npmt  <- nk+np+2*flSV+1       # the number of parameters
vsamp <- rep(0, npmt)         # sample box
msamp <- matrix(0, nsim, npmt)  # store box
msampa <- msampas <- matrix(0, ns, np)
vsamph <- vsamphs <- rep(0, ns)
nK <- floor(ns/30)-1            # blocks for sampling h


##-- MCMC sampling --##

cat('\nIteration:\n')

##----------------- S A M P L I N G   S T A R T ----------------##

for(k in (-nburn+1):nsim){

  if (nk > 0) {

    ##--- sampling beta ---##

    mBh <- solve(miB0 + t(mx) %*% (mx / matrix(vsigt2, ns, nk)))
    vbh <- mBh %*% (vBb0 + t(mx) %*% ((vy - vza) / vsigt2))

    vb <- vbh + t(chol(mBh)) %*% rnorm(nk)
    vxb <- mx %*% vb

  }

  if (np > 0) {

    ##--- sampling alpha ---##

    vya <- vy - vxb

    va <- va0
    mP <- mSig0
    mH2 <- mSig
    vr <- vr * 0
    mU <- mU * 0

    for (t in 1:ns) {
      ve[t] <- vya[t] - mz[t, ] %*% va
      vDi[t] <- 1 / (mz[t, ] %*% mP %*% mz[t, ] + vsigt2[t])

      vK <- mP %*% mz[t, ] * vDi[t]
      amL[, , t] <- mT - vK %*% mz[t, ]

      va <- va + vK %*% ve[t]
      mP <- mP %*% t(amL[, , t]) + mH2
    }

    for (t in ns:1) {
      mC <- mH2 - mH2 %*% mU %*% mH2
      mC <- (mC + t(mC)) / 2

      mCi <- solve(mC)

      veps <- t(chol(mC)) %*% rnorm(np)
      meta[t, ] <- mH2 %*% vr + veps

      mV <- mH2 %*% mU %*% amL[, , t]
      vr <- mz[t, ] * vDi[t] * ve[t] + t(amL[, , t]) %*% vr -
        t(mV) %*% mCi %*% veps
      mU <- matrix(mz[t, ] * vDi[t], np, 1) %*% matrix(mz[t, ], 1, np) +
        t(amL[, , t]) %*% mU %*% amL[, , t] + t(mV) %*% mCi %*% mV
    }

    mC <- mSig0 - mSig0 %*% mU %*% mSig0
    mC <- (mC + t(mC)) / 2
    veta0 <- mSig0 %*% vr + chol(mC) %*% rnorm(np)

    ma[1, ] <- va0 + veta0
    for (t in 1:(ns-1)) {
      ma[t+1, ] <- ma[t, ] + meta[t, ]
    }

    vza <- rowSums(mz * ma)


    ##--- sampling Sigma ---##

    mdif <- diff(ma)
    mOmh <- miOm0 + t(mdif) %*% mdif

    mSigi <- rWishart(1, dnuh, solve(mOmh))
    mSig <- solve(matrix(mSigi, np, np))

  }

  if (flSV == 1) {

    ##--- sampling SV ---##

    vya <- (vy - vxb - vza) / sqrt(dgam)

    vh <- svsamp(vya, vh, dphi, dsiget^2,
                 dsiget^2/(1-dphi^2), nK)


    ##--- sampling phi ---##

    dsum <- sum(vh[2:(ns-1)]^2)
    dmup <- sum(vh[1:(ns-1)] * vh[2:ns]) / dsum
    dsigp <- dsiget / sqrt(dsum)

    dphin <- 1
    while (abs(dphin) >= 1) {
      dphin <- dmup + rnorm(1) * dsigp
    }

    dfrac <- dbeta((dphin + 1) / 2, da0, db0) /
             dbeta((dphi + 1) / 2, da0, db0) *
             sqrt(1-dphin^2) / sqrt(1-dphi^2)

    if (runif(1) < dfrac) {
      dphi <- dphin
    }   


    ##--- sampling sigma_eta ---##

    vh1 <- vh[2:ns] - dphi * vh[1:(ns-1)]
    dVh <- dV0 + (1-dphi^2) * vh[1]^2 + sum(vh1^2)

    dsiget <- 1 / sqrt(rgamma(1, dvh/2, dVh/2))


    ##--- sampling gamma ---##

    dWh <- dW0 + sum((vy - vxb - vza)^2 / exp(vh))
    dgam <- 1 / rgamma(1, dgh/2, dWh/2)

    vsigt2 <- dgam * exp(vh)



  } else {

    ##--- sampling sigma ---##

    dSh <- dS0 + sum((vy - vxb - vza)^2)
    dsig <- 1 / sqrt(rgamma(1, dsh/2, dSh/2))

    vsigt2 <- rep(1, ns) * dsig^2

  }

  if (k >= 1) {

    ##--- storing sample ---##

    if (nk > 0) {
      vsamp[1:nk] <- vb
    }
    if (np > 0) {
      vsamp[(nk+1):(nk+np)] <- diag(mSig)
    }
    if (flSV == 1) {
      vsamp[(nk+np+1):npmt] <- c(dphi, dsiget, dgam)
    } else {
      vsamp[npmt] <- dsig
    }

    msamp[k, ] <- vsamp

    if (np > 0) {
      msampa  <- msampa  + ma
      msampas <- msampas + ma^2
    }
    if (flSV == 1) {
      vsamph  <- vsamph  + dgam * exp(vh)
      vsamphs <- vsamphs + dgam^2 * exp(vh*2)

    }

  }

  if((k %% 100) == 0) cat(k, '\n')

}
##------------------- S A M P L I N G   E N D ------------------##

##--- output results ---##

## Parameters
mout <- matrix(0, npmt, 4)
for (i in 1:npmt) {
  mout[i, ] <- c(mean(msamp[, i]), sd(msamp[, i]),
                 quantile(msamp[, i], .025, type=1),
                 quantile(msamp[, i], .975, type=1))
}
vspar <- numeric(0)
if (nk > 0) {
  for (i in 1:nk) {
    vspar <- c(vspar, paste('beta', i, sep=''))
  }
}
if (np > 0) {
  for (i in 1:np) {
    vspar <- c(vspar, paste('Sig', i, i, sep=''))
  } 
}
if (flSV == 1) {
  vspar <- c(vspar, c('phi  ', 'siget', 'gamma'))
} else {
  vspar <- c(vspar, 'sigma')
}

cat('\n')
cat('--------------------------------------------\n')
cat('Parameter  Mean     Stdev    95%L     95%U\n')
cat('--------------------------------------------\n')
for (i in 1:npmt) {
  cat(paste(vspar[i], ' ',
            sprintf('%7.4f', mout[i, 1]), '',
            sprintf('%7.4f', mout[i, 2]), '',
            sprintf('%7.4f', mout[i, 3]), '',
            sprintf('%7.4f', mout[i, 4]), '\n'))
}
cat('--------------------------------------------\n')
cat('TVP regression with ')
if (flSV == 0){
  cat('Constant Variance\n')
} else {
  cat('SV\n')
}

## TVP
msampa  <- msampa / nsim
msampas <- sqrt(msampas / nsim - msampa^2)

## SV
vsamph  <- vsamph / nsim
vsamphs <- sqrt(vsamphs / nsim - vsamph^2)

mout <- matrix(0, ns, (np+1)*2)
svar <- rep('', (np+1)*2)
for (i in 1:np) {
  mout[, (i-1)*2+(1:2)] <- cbind(msampa[, i], msampas[, i])
  svar[(i-1)*2+(1:2)] <- cbind(paste('Var', i, '-Mean', sep=''),
                               paste('Var', i, '-SD', sep=''))
}
mout[, i*2+(1:2)] <- cbind(vsamph, vsamphs)
svar[i*2+(1:2)] <- c('SV-Mean', 'SV-SD')

colnames(mout) <- svar
write.csv(mout, paste('tvpr_result.csv'), row.names = F)


##--- run time ---##

total.time <- proc.time() - tic.time
message('\nTime(s): ', round(total.time[3], 1))

