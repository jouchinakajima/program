/*---------------------------------------------------------
                         ASV.h
---------------------------------------------------------*/
											 
/*
**  HEADER FILE for ASV.ox
*/

class ASV
{
	decl m_iRun, m_iLev, m_iDens, m_vy, m_vyorg, m_ns;
	decl m_ncount, m_vh_t, m_vini, m_flMax;
	decl m_dap0, m_dbp0, m_dn0, m_dS0, m_dmm0, m_dsm0;
	decl m_dar0, m_dbr0, m_dnn0, m_dnS0, m_dtn0, m_dtS0;
	decl m_vY, m_vd, m_vmi, m_vvi, m_vai, m_vbi, m_k, m_vl;
	decl m_cmg, m_can, m_cmn, m_dcst, m_vvl, m_vml;
	
	ASV(const vdata);	//constructer

	SetModel(const iLev, const iDens);
	SetRanseed(const irs);
	SetCount(const ncount);
	
	SimData(const ns, const dphi, const dsig, const dbeta,
			const drho_a, const dnutau_a);	//simulate data
	SetIni(const dphi, const dsig, const dbeta, const drho,
		   const dnutau);	//set initial
 	DrawData(); //draw data (& state)

	MCMC(const nsim);
	fLogL(const vp, const dfunc, const vsc,	const mhe);
	Augkf(const vphi, const mH, const vP1, const mWtb,
		  const vWtB);
	SimS(const mH, const ve, const vD, const vK, const vL,
		 const dOm0);
	SampVol(const dphio, const dsigo, const drhoo);
	SetLam(const dphi, const dsig, const dmu, const drho,
		   const vh);
	fPosNu(const dp, const dfunc, const dsc, const dhe);
	SampNu(const dnuo, const vl);
	fPosTau(const dp, const dfunc, const dsc, const dhe);
	SampTau(const dtauo);
	SampLam(const dpar, const vlo);
	SampSt(const dphi, const dsig, const dmu, const drho,
		   const vh, const vp_i, const vm_i, const vv_i,
		   const va_i, const vb_i);

	fTsvar(const vx, const iBm);  //convergence diagnostics
	fGeweke(const vx, const iBm);
	
};
