%%--------------------------------------------------------%%
%%                    TVP-R package                       %%
%%--------------------------------------------------------%%

%%
%%  [] = simobs(...)
%%
%%  "simobs" simulates observation from TVP-R model
%%
%%  [input]
%%  if stochastic volatility:
%%   (ns, vb, va0, mSig, dphi, dsiget, dgam)
%%      ns:     # of sample
%%      vb:     beta (k*1 vector)
%%      va0:    alpha (p*1 vector, initial value)
%%      mSig:   Sigma (p*p matrix)
%%      dphi:   phi (scalar)
%%      dsiget: sigma_eta (scalar)
%%      dgam:   gamma (scalar)
%%
%%  if constant volatility:
%%    (ns, vb, va0, mSig, dsig)
%%      ns:     # of sample
%%      vb:     beta (k*1 vector)
%%      va0:    alpha (p*1 vector, initial value)
%%      mSig:   Sigma (p*p matrix)
%%      dsig:   sigma (scalar)
%%
%%  [output] >>> as a file
%%      [vy, mx, mz, ma, vh]
%%

function simobs(ns, vb, va0, mSig, darg, dsiget, dgam)

rand('state', 1);
randn('state', 1);

%%--- check arguments ---%%

if nargin == 7
    flSV = 1;
    dphi = darg;
elseif nargin == 5
    flSV = 0;
    dsig = darg;
else
    fprintf('\nError: Wrong number of arguments');
    fprintf(' -> simobs()\n');
end

%%--- simulate observation ---%%

nk = size(vb, 1);
if nk > 0
    mx = rand(ns, nk) - 0.5;
    vxb = mx * vb;
else
    mx = [];
    vxb = 0;
end

np = size(va0, 1);
if np > 0
    mz = rand(ns, np) - 0.5;
    ma = [va0' ; zeros(ns-1, np)];
    mSigch = chol(mSig);
    for i = 1 : ns-1
        ma(i+1, :) = ma(i, :) + randn(1, np) * mSigch;
    end
    vza = sum(mz .* ma, 2);
else
    mz = [];
    ma = [];
    vza = 0;
end

if flSV == 1
    vh = [randn() * dsiget / sqrt(1 - dphi^2); ...
          zeros(ns-1, 1)];
    for i = 1 : ns-1                % stochastic volatility
        vh(i+1) = dphi * vh(i) + randn() * dsiget;
    end
    vsigt = sqrt(dgam) * exp(vh/2);
else
    vh = [];
    vsigt = ones(ns, 1) * dsig;     % constant volatility
end

vy = vxb + vza + randn(ns, 1) .* vsigt;


%%--- save observation ---%%

mdata = [vy, mx, mz, ma, vh];
asl = cell(1, nk+np*2+flSV+1);
asl{1, 1} = 'y';
for i = 1 : nk
    asl{1, i+1} = ['x', num2str(i)];
end
for i = 1 : np
    asl{1, nk+i+1} = ['z', num2str(i)];
    asl{1, nk+np+i+1} = ['a', num2str(i)];
end
if flSV == 1
    asl{1, nk+np*2+2} = 'h';
end

if isequal(exist('tvpr_sim.xlsx', 'file'), 2)
  delete('tvpr_sim.xlsx');
end
xlswrite('tvpr_sim.xlsx', asl, 'Sheet1', 'A1');
xlswrite('tvpr_sim.xlsx', mdata, 'Sheet1', 'A2');

fprintf('\n  simobs.m -> output simulated observation ');
fprintf('as tvpr_sim.xlsx\n\n');
