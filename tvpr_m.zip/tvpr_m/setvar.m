%%--------------------------------------------------------%%
%%                    TVP-R package                       %%
%%--------------------------------------------------------%%

%%
%%  [] = setvar(...)
%%
%%  "setvar" sets variables or options as global variable
%%
%%  [input]
%%   (stype, ...)
%%
%%   ('data', vy, mx, mz) -> set data
%%
%%   ('vol', flSV)  ->  set volatility type
%%      1: stochastic volatility (default)
%%      0: constant voaltility
%%
%%   ('ranseed', iseed)  ->  set ranseed (default: 1)
%%
%%   ('prior', spar, ., .) -> set prior
%%
%%  [global variables]
%%      m_vy:    variable y_t (n*1 vector)
%%      m_mx:    variable x_t (n*k matrix)
%%      m_mz:    variable z_t (n*p matrix)
%%      m_ns:    # of observation (n, scalar)
%%      m_flSV:  volatility type (flag)
%%
%%      m_vb0 m_mB0 m_dnu0 m_mOm0 m_mSig0 m_da0 m_db0
%%      m_dv0 m_dV0 m_dg0 m_dW0 m_ds0 m_dS0: priors
%%

function setvar(stype, arg1, arg2, arg3)

global m_vy m_mx m_mz m_ns m_flSV m_iseed ...
       m_vb0 m_mB0 m_dnu0 m_mOm0 m_mSig0 m_da0 m_db0 ...
       m_dv0 m_dV0 m_dg0 m_dW0 m_ds0 m_dS0

switch stype
    case 'data'
        m_vy = arg1;
        m_mx = arg2;
        m_mz = arg3;
        m_ns = size(m_vy, 1);
    case 'vol'
        m_flSV  = arg1;
    case 'ranseed'
        m_iseed  = arg1;
    case 'prior'
      switch arg1
          case 'beta'
            m_vb0 = arg2;    % mu ~ N(b0, B0)
            m_mB0 = arg3;
          case 'Sigma'
            m_dnu0 = arg2;   % Sigma
            m_mOm0 = arg3;   %  ~ InvWishart(nu0, Om0)     
          case 'a1'
            m_mSig0 = arg2;  % a1 ~ N(0, Sig0)
          case 'phi'
            m_da0 = arg2;    % (phi+1)/2 ~ Beta(a0, b0)
            m_db0 = arg3;
          case 'siget'
            m_dv0 = arg2;    % sigma_eta^2
            m_dV0 = arg3;    %  ~ InvGamma(v0/2, V0/2)
          case 'gamma'
            m_dg0 = arg2;    % gamma
            m_dW0 = arg3;    %  ~ InvGamma(g0/2, W0/2) 
          case 'sigma'
            m_ds0 = arg2;    % sigma^2
            m_dS0 = arg3;    %  ~ InvGamma(s0/2, S0/2)              
      end
end
