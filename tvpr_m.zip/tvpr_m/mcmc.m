%%--------------------------------------------------------%%
%%                    TVP-R package                       %%
%%--------------------------------------------------------%%

%%
%%  [] = mcmc(nsim)
%%
%%  "mcmc" implements MCMC estimation for TVP-R model
%%
%%  [input]
%%      nsim:  # of MCMC iterations
%%
%%

function mcmc(nsim)

global m_vy m_mx m_mz m_ns m_flSV m_iseed ...
       m_vb0 m_mB0 m_dnu0 m_mOm0 m_mSig0 m_da0 m_db0 ...
       m_dv0 m_dV0 m_dg0 m_dW0 m_ds0 m_dS0 m_k ...
       m_iachar m_iachmh
   
tic;

%%--- set default options ---%%

if isempty(m_flSV) == 1
    m_flSV = 1;
end
if isempty(m_iseed) == 1
    m_iseed = 1;
end

rand('state', m_iseed);
randn('state', m_iseed);


%%--- set variables ---%%

nk = size(m_mx, 2);
np = size(m_mz, 2);
    

%%--- prior ---%%

if isempty(m_vb0) == 1
  m_vb0 = zeros(nk, 1);    % mu ~ N(b0, B0)
  m_mB0 = eye(nk) * 10;
end
if isempty(m_dnu0) == 1
  m_dnu0  = 4;             % Sigma ~ InvWishart(nu0, Om0)
  m_mOm0  = eye(np) * 40;    
end
if isempty(m_mSig0) == 1
  m_mSig0 = eye(np) * 10;  % a1 ~ N(0, Sig0)
end
if isempty(m_da0) == 1
  m_da0 = 20;              % (phi+1)/2 ~ Beta(a0, b0)
  m_db0 = 1.5;
end
if isempty(m_dv0) == 1
  m_dv0 = 4;        % sigma_eta^2 ~ InvGamma(v0/2, V0/2)
  m_dV0 = 0.04;
end
if isempty(m_dg0) == 1
  m_dg0 = 4;        % gamma ~ InvGamma(g0/2, W0/2)
  m_dW0 = 0.04;
end
if isempty(m_ds0) == 1
  m_ds0 = 4;        % sigma^2 ~ InvGamma(s0/2, S0/2)
  m_dS0 = 0.04;
end


%%--- set initial ---%%

vb   = zeros(nk, 1);
ma   = zeros(m_ns, np);
mSig = eye(np) * 0.1;
vh   = zeros(m_ns, 1);
dphi = 0.95;
dsiget = 0.1;
dgam = 0.1;
dsig = 0.1;

    
%%--- set variables ---%%

miB0  = inv(m_mB0);
vBb0  = miB0 * m_vb0;
miOm0 = inv(m_mOm0);
dnuh  = m_dnu0 + m_ns - 1;
dvh   = m_dv0 + m_ns;
dgh   = m_dg0 + m_ns;
dsh   = m_ds0 + m_ns;

vsigt2 = dgam * exp(vh);
vxb = zeros(m_ns, 1);
vza = zeros(m_ns, 1);


%%--- set sampling option ---%%

nburn = 0.1 * nsim;         % burn-in period
npmt = nk+np+2*m_flSV+1;    % # of parameter
msamp = zeros(nsim, npmt);  % sample box
vsamp = zeros(1, npmt);
msampa  = zeros(m_ns, np);
msampas = zeros(m_ns, np);
msamph  = zeros(m_ns, 2);
iacphi = 0;                 % acceptance counter
m_iachar = 0;
m_iachmh = 0;
nK = floor(m_ns/30)-1;      % # of blocks for sampling h


%%--- MCMC sampling ---%%

fprintf('\nIteration:\n');

%%------------- S A M P L I N G   S T A R T --------------%%

for m_k = -nburn : nsim

if nk > 0

  %%--- sampling beta ---%%

    mBh = inv(miB0 + m_mx' * (m_mx ./ (vsigt2*ones(1,nk))));
    vbh = mBh * (vBb0 + m_mx' * ((m_vy - vza) ./ vsigt2));

    vb = vbh + chol(mBh) * randn(nk, 1);
    vxb = m_mx * vb;

end

if np > 0
    
  %%--- sampling alpha ---%%

    ma = ssmooth(m_vy-vxb, m_mz, vsigt2, eye(np), mSig, ...
                 zeros(np, 1), m_mSig0)';

    vza = sum(m_mz .* ma, 2);

  %%--- sampling Sigma ---%%

    mdif = ma(2:end, :) - ma(1:end-1, :);
    mOmh = miOm0 + mdif' * mdif;

    mSig = inv(wishrnd(inv(mOmh), dnuh));

end

if m_flSV == 1
    
  %%--- sampling h ---%%
  
    vh = svsamp((m_vy-vxb-vza)/sqrt(dgam), vh, dphi, ...
                dsiget^2, dsiget^2/(1-dphi^2), nK);

  %%--- sampling phi ---%%

    dsum = vh(2:end-1)' * vh(2:end-1);
    dmup = vh(1:end-1)' * vh(2:end) / dsum;
    dsigp = dsiget / sqrt(dsum);
  
    dphin = 1;
    while abs(dphin) >= 1
        dphin = dmup + randn() * dsigp;    % proposal
    end
    
    dfrac = betapdf((dphin+1)/2, m_da0, m_db0) ...
          / betapdf((dphi+1)/2, m_da0, m_db0) ...
          * sqrt(1-dphin^2) / sqrt(1-dphi^2);

    if rand() < dfrac
        dphi = dphin;       % accept
        if m_k >= 0
          iacphi = iacphi + 1;
        end
    end

    
  %%--- sampling sigma_eta ---%%

    vh1 = vh(2:end) - dphi * vh(1:end-1);
    dVh = m_dV0 + (1-dphi^2)*vh(1)^2 + vh1' * vh1;
    dsiget = 1 / sqrt(gamrnd(dvh/2, 2/dVh));


  %%--- sampling gamma ---%%

    dWh = m_dW0 + sum((m_vy - vxb - vza).^2 ./ exp(vh));
    dgam = 1 / gamrnd(dgh/2, 2/dWh);

    vsigt2 = dgam * exp(vh);

    
else
    
  %%--- sampling sigma ---%%

    dSh = m_dS0 + sum((m_vy - vxb - vza).^2);
    dsig = 1 / sqrt(gamrnd(dsh/2, 2/dSh));
    
    vsigt2 = ones(m_ns, 1) * dsig^2;
  
end

    
%%--- storing sample ---%%

    if m_k > 0
        if nk > 0
            vsamp(1:nk) = vb';
        end
        if np > 0
            vsamp(nk+1:nk+np) = diag(mSig)';
        end
        if m_flSV == 1
            vsamp(nk+np+1:end) = [dphi, dsiget, dgam];
        else
            vsamp(end) = dsig;
        end

        msamp(m_k, :) = vsamp;
    
        if np > 0
            msampa  = msampa + ma;
            msampas = msampas + ma.^2;
        end
        if m_flSV == 1
            msamph = msamph ...
                   + [dgam*exp(vh), dgam.^2*exp(vh*2)];
        end
    end

    if mod(m_k, 1000) == 0       % print counter
        fprintf('%i \n', m_k);
    end

end

%%--------------- S A M P L I N G   E N D ----------------%%

%%--- output result ---%%

iBm = min([500, nsim/2]);   % bandwidth
iacf = iBm;

aspar = [];
aspar2 = [];
if nk > 0
    for i = 1 : nk
        ii = i - floor(i/10)*10;
        aspar = strvcat(aspar, sprintf('beta%i', ii));
        aspar2 ...
         = strvcat(aspar2, sprintf('  \\beta_%i', ii));
    end
end
if np > 0
    for i = 1 : np
        ii = i - floor(i/10)*10;
        aspar = strvcat(aspar, sprintf('Sig%i%i', ii, ii));
        aspar2 ...
         = strvcat(aspar2, sprintf('\\Sigma_{%i%i}', ...
                                  ii, ii));
    end
end

if m_flSV == 1
  aspar = strvcat(aspar, 'phi', 'siget', 'gamma');
  aspar2 ...
    = strvcat(aspar2, '   \phi', '\sigma_\eta', '  \gamma');
else
  aspar = strvcat(aspar, 'sigma');
  aspar2 = strvcat(aspar2, '  \sigma');
end    
    
    
fprintf('\n\n                        [ESTIMATION RESULT]')
fprintf('\n----------------------------------')
fprintf('------------------------------------')
fprintf('\nParameter    Mean      Stdev       ')
fprintf('95%%U       95%%L    Geweke     Inef.')
fprintf('\n----------------------------------')
fprintf('------------------------------------\n')

for i = 1 : npmt
    vsamp = msamp(:, i);
    vsamp_s = sort(vsamp);
fprintf('%s %11.4f %10.4f %10.4f %10.4f %9.3f %9.2f\n',...
        aspar(i, :), ...
        [mean(vsamp), std(vsamp), ...
         vsamp_s(floor(nsim*[0.025;0.975]))'], ...
         fGeweke(vsamp, iBm), ...
         ftsvar(vsamp, iBm)/var(vsamp))
end          

fprintf('-----------------------------------')
fprintf('-----------------------------------')
fprintf('\nTVP regression with ')
if m_flSV == 1
     fprintf('stochastic')
else fprintf('constant')
end
fprintf(' volatility\nIteration: %i', nsim)

% if m_flSV == 1
%     fprintf('\n\nAcceptance rate for multi-move sampler')
%     fprintf('\n AR step: %5.1f', (nK+1)*nsim/m_iachar*100)
%     fprintf('%%\n MH step: %5.1f', ...
%             m_iachmh/((nK+1)*nsim)*100)
%     fprintf('%%\nAcceptance rate for phi')
%     fprintf('\n MH step: %5.1f%%', iacphi/nsim*100)    
% end


%%--- output graphs ---%%

vacf = zeros(iacf, 1);
for i = 1 : npmt
    for j = 1 : iacf
        macf = corrcoef(msamp(j+1:end, i), ...
                           msamp(1:end-j, i));
        vacf(j) = macf(2, 1);
    end
    subplot(3, npmt, i)        
    sysh = stem(vacf);              % autocorrelation
    set(sysh, 'Marker', 'none')
    axis([0 iacf -1 1])
    title(aspar2(i, :))
    subplot(3, npmt, npmt+i);
    plot(msamp(:, i))               % sample path
    title(aspar2(i, :))
    vax = axis;
    axis([0 nsim vax(3:4)])
    subplot(3, npmt, npmt*2+i)
    hist(msamp(:, i), 15)           % posterior density
    title(aspar2(i, :))
end

if np > 0
  
  %%--- draw alpha ---%%
    
    msampa = msampa / nsim; % posterior mean
    msampas = sqrt(msampas/nsim - msampa.^2);
                            % posterior standard deviation
    ml = msampa - msampas * 2;
    mu = msampa + msampas * 2;
    
    figure
    for i = 1 : np
        subplot(np, 1, i);
        plot(msampa(:, i))
        hold on
        plot(ml(:, i), 'r:')
        plot(mu(:, i), 'r:')
        hold off
        title(sprintf('%s%i%s', '\alpha_{', i, '}'))
        if i == 1
            legend('Posterior mean', '2SD bands')
        end
    end
    
    % output to file
    mout = [msampa msampas];
    
    asl = cell(1, np*2);
    for i = 1 : np
        asl{1, i} = ['Mean: Var', num2str(i)]; 
        asl{1, np+i} = ['Stdev: Var', num2str(i)]; 
    end

    if isequal(exist('tvpr_alpha.xlsx', 'file'), 2)
      delete('tvpr_alpha.xlsx');
    end
    xlswrite('tvpr_alpha.xlsx', asl, 'Sheet1', 'A1');
    xlswrite('tvpr_alpha.xlsx', mout, 'Sheet1', 'A2');
end

if m_flSV == 1

  %%--- draw h ---%%

    msamph(:, 1) = msamph(:, 1) / nsim; % posterior mean
    msamph(:, 2) ...
        = sqrt(msamph(:, 2)/nsim - msamph(:, 1).^2);
                              % posterior standard deviation  

    figure
    subplot(2, 1, 1);
    plot(m_vy)
    title('Dependent variable $y_t$', ...
          'interpreter', 'latex')
    subplot(2, 1, 2);
    plot(msamph(:, 1))
    hold on
    plot(msamph(:, 1) - msamph(:, 2), 'r:')
    plot(msamph(:, 1) + msamph(:, 2), 'r:')
    hold off
    title('Estimated volatility $\sigma_t^2=\gamma\exp(h_t)$', ...
          'interpreter', 'latex')
    legend('Posterior mean', '1SD bands')
    
    % output to file
    if isequal(exist('tvpr_vol.xlsx', 'file'), 2)
      delete('tvpr_vol.xlsx');
    end
    xlswrite('tvpr_vol.xlsx', {'Mean', 'Stdev'}, 'Sheet1', 'A1');
    xlswrite('tvpr_vol.xlsx', msamph, 'Sheet1', 'A2');

end

fprintf('\n\nRanseed: %i', m_iseed);
fprintf('\nTime: %.2f', toc);
fprintf('\n\n')

