%%--------------------------------------------------------%%
%%                     tvpr_ex1.ox                        %%
%%--------------------------------------------------------%%
											 
%%
%%  MCMC estimation for Time-Varying Parameter Regression
%%  (TVP-R) model with stochastic volatility
%%
%%  tvpr_ex*.ox illustrates MCMC estimation
%%  using TVP-R Package
%%
%%  ex1: "tvpr_sim1.xlsx" data (stochastic volatility)
%%  ex2: "tvpr_sim2.xlsx" data (constant volaitlity)
%%

clear all;
close all;

%%--- data load ---%%

mdata = xlsread('tvpr_sim1.xlsx');

vy = mdata(:, 1);
mx = mdata(:, 2:3);
mz = mdata(:, 4:5);

setvar('data', vy, mx, mz);

mcmc(10000);
