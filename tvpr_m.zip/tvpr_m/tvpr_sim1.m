%%--------------------------------------------------------%%
%%                     tvpr_sim1.ox                       %%
%%--------------------------------------------------------%%
											 
%%
%%  MCMC estimation for Time-Varying Parameter Regression
%%  (TVP-R) model with stochastic volatility
%%
%%  tvpr_sim*.ox simulates observation from TVP-R model
%%  using TVP-R Package
%%
%%  sim1: stochastic volatility
%%  sim2: constant volatiliy
%%

clear all;
close all;


%%--- true parameter ---%%

ns = 500;			% # of sample

vb   = [4; -1];		% beta
va0  = [-2; 3];		% alpha (initial)
mSig = eye(2)*.01;	% Sigma
dphi = 0.95;		% phi
dsiget = 0.1;		% sigma_eta
dgam = 0.5;			% gamma


%%--- simulate observation (stochastic volatility) ---%%

simobs(ns, vb, va0, mSig, dphi, dsiget, dgam);

