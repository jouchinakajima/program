%%--------------------------------------------------------%%
%%                     tvpr_sim2.ox                       %%
%%--------------------------------------------------------%%
											 
%%
%%  MCMC estimation for Time-Varying Parameter Regression
%%  (TVP-R) model with stochastic volatility
%%
%%  tvpr_sim*.ox simulates observation from TVP-R model
%%  using TVP-R Package
%%
%%  sim1: stochastic volatility
%%  sim2: constant volatiliy
%%

clear all;
close all;


%%--- true parameter ---%%

ns = 500;			% # of sample

vb   = [4; -1];		% beta
va0  = [-2; 3];		% alpha (initial)
mSig = eye(2)*.01;	% Sigma
dsig = 1;           % sigma


%%--- simulate observation (constant volatility) ---%%

simobs(ns, vb, va0, mSig, dsig);

