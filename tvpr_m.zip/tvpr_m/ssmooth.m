%%--------------------------------------------------------%%
%%                    TVP-R package                       %%
%%--------------------------------------------------------%%

%%
%%  malpha = ssmooth(vy, mz, vG2, mT, mH2, va0, mH02)
%%
%%  "ssmooth" implements simulation smoother
%%  by de Jong & Shephard (1995)
%%
%%  [model]
%%      y_t = z_t'*alpha_t + G_t*e_t
%%      alpha_{t+1} = T_t*alpha_t + H_t*e_t
%%      e_t ~ N(0, I)
%%      G_t*H_t' = O
%%
%%      y_t:     scalar
%%      z_t:     np*1 vector
%%      alpha_t: np*1 vector
%%      G_t:     1*(np+1) vector
%%      T_t:     np*np matrix
%%      H_t:     np*(np+1) matrix
%%
%%  [input]
%%      vy:     response (ns*1 vector)
%%      mz:     independent variable (ns*np matrix)
%%      vG2:    G_t*G_t' (ns*1 vector)
%%      mT:     T_t = T (np*np matrix)
%%      mH2:    H_t*H_t' = H*H' (np*np matrix)
%%      va0:    alpha_0 (np*1 vector)
%%      mH02:   H_0*H_0' (np*np matrix)
%%
%%  [output]
%%      malpha:  sampled state variable (np*ns matrix)
%%

function malpha = ssmooth(vy, mz, vG2, mT, mH2, va0, mH02)

%%--- set variables ---%%

ns = size(vy, 1);    % # of observation
np = size(mz, 2);    % # of state

va = va0;
mP = mH02;
vr = zeros(np, 1);
mU = zeros(np);

ve = zeros(ns, 1);
vDinv = zeros(ns, 1);
amL = zeros(np, np, ns);
meta = zeros(np, ns);

%--- Kalman filter ---%%

for i = 1 : ns
    ve(i) = vy(i) - mz(i, :) * va;
    vDinv(i) = 1 / (mz(i, :)*mP*mz(i, :)' + vG2(i));
    mK = mT * mP * mz(i, :)' * vDinv(i);
    amL(:, :, i) = mT - mK * mz(i, :);
    
    va = mT * va + mK * ve(i);
    mP = mT * mP * amL(:, :, i)' + mH2;
end

%%--- simulation smoother ---%%

i = ns;
while i >= 1
    mC = mH2 - mH2 * mU * mH2;
    mC = (mC + mC')/2;
    [mCc, fl] = chol(mC, 'lower');
    drC = rcond(mC);
    if fl > 0
        mCc = eye(np) * 0.01;
        mCinv = eye(np) * 10^4;
    elseif isnan(drC) || (drC < eps*10^2)
        mCinv = eye(np) * 10^4;
    else
        mCinv = inv(mC);
    end
    
    veps = mCc * randn(np, 1);
    meta(:, i) = mH2 * vr + veps;
    mV = mH2 * mU * amL(:, :, i);
    
    vr = mz(i, :)' * vDinv(i) * ve(i) ...
       + amL(:, :, i)' * vr ...
       - mV' * mCinv * veps;
    mU = mz(i, :)' * vDinv(i) * mz(i, :) ...
       + amL(:, :, i)' * mU * amL(:, :, i) ...
       + mV' * mCinv * mV;
    
    i = i - 1;
end

mC = mH02 - mH02 * mU * mH02;
mC = (mC + mC')/2;
[mCc, fl] = chol(mC, 'lower');
if fl > 0
    mCc = eye(np) * 0.07;
end
veta0 = mH02 * vr + mCc * randn(np, 1);

malpha = zeros(np, ns);
malpha(:, 1) = va0 + veta0;
for i = 1 : ns-1
    malpha(:, i+1) = mT * malpha(:, i) + meta(:, i);
end

