%%--------------------------------------------------------%%
%%                   TVP-R package                        %%
%%--------------------------------------------------------%%
%%              coded by Jouchi Nakajima                  %%
%%--------------------------------------------------------%%
%%                Last update: 2020/05/01                 %%
%%       http://sites.google.com/site/jnakajimaweb/       %%
%%--------------------------------------------------------%%
%%    You may use and modify this code at your own risk   %%
%%--------------------------------------------------------%%
											 
%%
%%  Function files for
%%  MCMC estimation of Time-Varying Parameter Regression
%%  (TVP-R) model with stochastic volatility
%%

%%  
%%  setvar.m    sets variables or options
%%  mcmc.m      implements MCMC estimation for TVP-R model
%%
%%  ssmooth.m   implements simulation smoother
%%  svsamp.m    implements multi-move sampler for SV model
%%  ftsvar.m    computes time-series variance  
%%  fGeweke.m   computes Geweke statistics for convergence
%% 
%%  simobs.m    simulates observation from TVR model
%%
%%  Note: this package requires statistics toolbox
%%

%%
%% [Illustrative examples]
%%
%%  tvpr_ex*.m   illustrates MCMC estimation
%%               _ex1: stochastic volatility (tvpr_sim1.xls)
%%               _ex2: constant volatility   (tvpr_sim2.xls)
%%
%%  tvpr_sim*.m  simulates observation from TVP-R model
%%               _sim1: stochastic volatility
%%               _sim2: constant volatility
%%
%%--------------------------------------------------------%%